

function setDate(dateString, jqueryInputElement) {
    if(jqueryInputElement instanceof jQuery)
        jqueryInputElement.val(dateString);
}


function getTodaysDate() {
    let now = new Date();
    return formatDateinYYYYMMDD(now);
}


function getPreviousDate(months) {
    let now = new Date();
    if (months > 0) {
        now.setMonth(now.getMonth() - months);
    }
    return formatDateinYYYYMMDD(now);

}

function formatDateinYYYYMMDD(date) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) 
        month = '0' + month;
    if (day.length < 2) 
        day = '0' + day;

    return [year, month, day].join('-');
}

